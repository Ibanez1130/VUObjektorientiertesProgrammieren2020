package bonus.spring.dto;

import java.util.ArrayList;
import java.util.Collection;

public class CashRegisters {

	private Collection<Long> cashRegisterIDs = new ArrayList<>();

	public Collection<Long> getCashRegisterIDs() {
		return cashRegisterIDs;
	}

	public void setCashRegisterIDs(Collection<Long> cashRegisterIDs) {
		this.cashRegisterIDs = cashRegisterIDs;
	}
	
	public void addCashRegisterID(Long id) {
		this.cashRegisterIDs.add(id);
	}
	
	// TODO: add additional attributes (if necessary)
}
