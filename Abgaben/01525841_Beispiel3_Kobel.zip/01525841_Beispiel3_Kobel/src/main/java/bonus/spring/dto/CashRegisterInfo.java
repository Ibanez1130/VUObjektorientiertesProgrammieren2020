/**
 * @name Konstantin Kobel
 * @martrikelnummer 01525841
 * @date 01.06.2020
 */
package bonus.spring.dto;

public class CashRegisterInfo {
	
	private Long id;
	private String info;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getInfo() {
		return info;
	}
	
	public void setInfo(String info) {
		this.info = info;
	}
	
	// TODO: expand your implementation here

}
