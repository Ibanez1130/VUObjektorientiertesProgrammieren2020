package bonus.spring;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class RestaurantManagementSystemSpring {

	public RestaurantManagementSystemSpring() {
		this.run();
	}

	public void run() {

		// TODO: Place your code from RestaurantManagementSystem here.
		// this method starts the application as normal. No special attention is needed
		// for the REST-Controllers in package bonus.spring.controllers

	}

	public static void main(String[] args) {
		SpringApplicationBuilder builder = new SpringApplicationBuilder(RestaurantManagementSystemSpring.class);
		builder.headless(false);
		builder.run(args);
	}
}
