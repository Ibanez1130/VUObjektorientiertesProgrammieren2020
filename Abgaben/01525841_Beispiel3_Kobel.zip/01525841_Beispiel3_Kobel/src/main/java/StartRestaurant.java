
public class StartRestaurant {

	public static void main(String[] args) {
		RestaurantManagementSystem.run();
	}
}
