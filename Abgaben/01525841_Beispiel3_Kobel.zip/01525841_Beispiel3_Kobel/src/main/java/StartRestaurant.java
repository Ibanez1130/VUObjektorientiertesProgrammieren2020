/**
 * @name Konstantin Kobel
 * @martrikelnummer 01525841
 * @date 30.05.2020
 */
import bonus.spring.RestaurantManagementSystemSpring;

public class StartRestaurant {

	public static void main(String[] args) {
		// RestaurantManagementSystem.run();
		new RestaurantManagementSystemSpring();
	}
}
