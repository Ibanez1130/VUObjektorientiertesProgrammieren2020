/**
 * @name Konstantin Kobel
 * @martrikelnummer 01525841
 * @date 13.03.2020
 */
package rbvs;

public enum OrderState {
	CANCELLED,
	OPEN,
	PAID
}
