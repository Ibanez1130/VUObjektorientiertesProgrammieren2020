/**
 * @name Konstantin Kobel
 * @martrikelnummer 01525841
 * @date 13.03.2020
 */
package ict.basics;

public interface IDeepCopy {
	IDeepCopy deepCopy();
}
