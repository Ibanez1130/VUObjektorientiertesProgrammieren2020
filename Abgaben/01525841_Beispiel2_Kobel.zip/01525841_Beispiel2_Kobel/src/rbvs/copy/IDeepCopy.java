/**
 * @name Konstantin Kobel
 * @martrikelnummer 01525841
 * @date 01.05.2020
 */
package rbvs.copy;

public interface IDeepCopy {

	public IDeepCopy deepCopy();
}
